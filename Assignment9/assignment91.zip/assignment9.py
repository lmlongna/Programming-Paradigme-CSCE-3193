# import sys
#
# # if len(sys.argv) != 3:
# #     exit('Please pass 2 arguments')
# #     # try:
# #     #     with open('emperor3.txt', 'r') as f:
# #     #         f_contents = f.read()
# #     #
# #     # except IndexError:
# #     #     f_contents = ' not enough argumants'
# #     # print(f_contents)
# # else:
# #     content_1 = sys.argv[1]
# #     content_2 = sys.argv[2]
# with open('emperor3.txt', 'r') as f:
#     f_content_1 = f.read()
#     f_content_1 = f_content_1.lower()
# with open('skip-words.txt', 'r') as f:
#
#     f_content_2 = f.read()
# #print(f_content_1)
# print(f_content_2)
# # list1 = f_content_1.strip()
# list1 = f_content_1.split()
# list2 = f_content_2.split()
# erasures = ['\n','\t','.','?','!',',',';',':','\'','\"']
# list1.remove()
# print(list1)
# #
# # erasures = ['\n','\t','.','?','!',',',';',':','\'','\"']
# # list1(filter(erasures, list1))
# # print(list)

import sys
import operator

#Getting the argument list.
args = sys.argv

#The condition check.
if len(args) != 3:
   print("Not enough arguments please pass 2 arguments")
   sys.exit()

storyFileName = args[1]
skipWordsFileName = args[2]

#Reading the files.
with open(storyFileName, 'r') as storyFile:
   storyString = storyFile.read()
   print('Story filename: ' + storyFileName)

with open(skipWordsFileName, 'r') as skipWordsFile:
   skipWordsString = skipWordsFile.read()
   skiplist = skipWordsString.split(',')
   print('Skip word file name: ' + skipWordsFileName)
   print('Skip words: ' + str(skiplist))


erasures = ['\n','\t','.','?','!',',',';',':','\'','\"']
for character in erasures:
   storyString = storyString.replace(character, ' ')


skipWordsString = skipWordsString.replace(' ', '')
skipWordsString = skipWordsString.lower()
skipWordsList = skipWordsString.split(',')
for word in skipWordsList:
   word = word.strip()

#filtering the story text.
storyString = storyString.lower()
storySplitList = storyString.split()
storySplitList = [word for word in storySplitList if word not in skipWordsList]
storyString = ' '.join(storySplitList)

storyList = storyString.split(' ')
storyList = list(filter(lambda a: a != '', storyList))

#creating the dictionary.
PairCount = {}
for i in range(len(storyList) - 1):
   if storyList[i] + ' ' + storyList[i+1] in PairCount:
       PairCount[storyList[i] + ' ' + storyList[i + 1]] += 1
   else:
       PairCount[storyList[i] + ' ' + storyList[i + 1]] = 1

#Sorting the dictionary.
storyCount = sorted(PairCount.items(), key=operator.itemgetter(1))

#Printing the  output.
print('The five most frequently occurring word pairs are:')

for i in range(1, 6):
    print(storyCount[-i])


