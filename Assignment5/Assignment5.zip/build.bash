#!/bin/bash
set -u -e
javac Controller.java
java Controller