
////////////////////////////////////////////
///////////   ASSIGNMENT 5       ///////////
////////// LAMBERT LONGNANG     ///////////
/////////     10-19-2019        //////////
//////////////////////////////////////////

import java.awt.*;

public class Bank extends Sprite {


    public Bank() {
        super("bank.png");
        this.setX(300);
        this.setY(300);
    }

    public void updateImage(Graphics g)
    {
        super.updateImage(g);
    }
}

